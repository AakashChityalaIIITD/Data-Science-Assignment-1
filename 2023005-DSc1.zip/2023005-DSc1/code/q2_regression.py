
import os

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from common import SEED, FIG, OUT, ensure_dirs, tic, save_json, env_info, load_kdd, build_D, build_y

MS = [50, 100, 200, 500, 1000, 2000, 5000]
REPS = 5
MS_D = [50, 500, 5000]
N_SKETCH_D = 100
SUBSET = 50_000
M_E = 500


def savefig(name):
    plt.tight_layout()
    plt.savefig(os.path.join(FIG, name), dpi=200)
    plt.close()


def loss(D, y, a):
    r = D @ a - y
    return float(r @ r)


def draw_countsketch_hash(n, m, rng):
    h = rng.integers(0, m, size=n)
    sg = rng.integers(0, 2, size=n) * 2.0 - 1.0
    return h, sg


def countsketch_apply(D, y, h, sg, m, chunk=100_000):
    SD = np.zeros((m, D.shape[1]))
    Sy = np.zeros(m)
    for s in range(0, len(D), chunk):
        e = s + chunk
        np.add.at(SD, h[s:e], sg[s:e, None] * D[s:e])
        np.add.at(Sy, h[s:e], sg[s:e] * y[s:e])
    return SD, Sy


def main():
    ensure_dirs()
    kdd = load_kdd()
    D32, summ = build_D(kdd)
    y = build_y(kdd)
    D = D32.astype(np.float64)
    del D32
    n, d = D.shape
    print(f"D: n={n}, d={d}; attack fraction={y.mean():.4f}", flush=True)
    res = {"n": n, "d": d, "env": env_info(), "attack_fraction": float(y.mean())}

    t0 = tic()
    b, _, rank_ls, sv = np.linalg.lstsq(D, y, rcond=None)
    t_b = tic() - t0
    loss_b = loss(D, y, b)
    r = int(np.linalg.matrix_rank(D))                      # rank(D), default tolerance
    res["a"] = {"loss_b": loss_b, "time_sec": t_b, "rank_D": r, "rank_from_lstsq": int(rank_ls),
                "singular_values_around_rank": {"sv_r": float(sv[r - 1]),
                                                "sv_r_plus_1": float(sv[r]) if r < d else None,
                                                "largest": float(sv[0]), "smallest": float(sv[-1])},
                "norm_b": float(np.linalg.norm(b))}
    print(f"(a) Loss(D,y,b)={loss_b:.6g} time={t_b:.2f}s rank(D)={r} (d={d})", flush=True)

    rows = []
    for m in MS:
        for rep in range(REPS):
            rng = np.random.default_rng([SEED, 10, m, rep])
            t0 = tic()
            h, sg = draw_countsketch_hash(n, m, rng)
            t_draw = tic() - t0
            t0 = tic()
            SD, Sy = countsketch_apply(D, y, h, sg, m)
            t_form = tic() - t0
            t0 = tic()
            a = np.linalg.lstsq(SD, Sy, rcond=None)[0]
            t_solve = tic() - t0
            L = loss(D, y, a)
            sk = float(np.sum((SD @ a - Sy) ** 2))
            rows.append({"m": m, "rep": rep, "loss": L, "ratio": L / loss_b, "sketched_loss": sk,
                         "sketched_over_loss_b": sk / loss_b,
                         "t_draw": t_draw, "t_form": t_form, "t_solve": t_solve,
                         "t_total": t_draw + t_form + t_solve})
            print(f"  m={m:5d} rep={rep}: ratio={L / loss_b:.5g} sketched={sk:.5g} t={t_draw + t_form + t_solve:.2f}s",
                  flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT, "q2_runs.csv"), index=False)
    agg = {}
    for m in MS:
        g = df[df.m == m]
        agg[m] = {"ratio_mean": g.ratio.mean(), "ratio_min": g.ratio.min(), "ratio_max": g.ratio.max(),
                  "loss_mean": g.loss.mean(), "sketched_mean": g.sketched_loss.mean(),
                  "sketched_min": g.sketched_loss.min(), "sketched_max": g.sketched_loss.max(),
                  "sketched_over_loss_b_mean": g.sketched_over_loss_b.mean(),
                  "t_draw": g.t_draw.mean(), "t_form": g.t_form.mean(), "t_solve": g.t_solve.mean(),
                  "t_total": g.t_total.mean(), "t_total_std": g.t_total.std(ddof=1),
                  "gaussian_reference_ratio": (1 + r / (m - r - 1)) if m > r + 1 else None}
    res["bc"] = agg

    def refline(ax):
        ax.axvline(r, color="gray", ls=":", label=f"m = rank(D) = {r}")

    plt.figure(figsize=(6.6, 4.2))
    mean = np.array([agg[m]["ratio_mean"] for m in MS])
    lo = np.array([agg[m]["ratio_min"] for m in MS]); hi = np.array([agg[m]["ratio_max"] for m in MS])
    plt.errorbar(MS, mean, yerr=[mean - lo, hi - mean], marker="o", capsize=4, label="mean (bars: min/max of 5)")
    refline(plt.gca()); plt.axhline(1, color="r", ls="--", lw=1, label="ratio = 1")
    plt.xscale("log"); plt.yscale("log")
    plt.xlabel("sketch size m"); plt.ylabel("Loss(D,y,a~) / Loss(D,y,b)")
    plt.title("Q2(b): loss ratio of the sketched solution"); plt.legend(fontsize=8)
    savefig("q2b_ratio_vs_m.png")

    plt.figure(figsize=(6.6, 4.2))
    sk = np.array([max(agg[m]["sketched_mean"], 1e-14) for m in MS])
    plt.plot(MS, sk, marker="o", label="mean sketched loss |SDa~ - Sy|^2 (floored at 1e-14)")
    plt.axhline(loss_b, color="r", ls="--", label="Loss(D,y,b)")
    refline(plt.gca()); plt.xscale("log"); plt.yscale("log")
    plt.xlabel("sketch size m"); plt.ylabel("sketched loss")
    plt.title("Q2(b): sketched loss versus m"); plt.legend(fontsize=8)
    savefig("q2b_sketched_loss_vs_m.png")

    plt.figure(figsize=(6.6, 4.2))
    tm = np.array([agg[m]["t_total"] for m in MS]); ts = np.array([agg[m]["t_total_std"] for m in MS])
    plt.errorbar(MS, tm, yerr=ts, marker="o", capsize=4, label="draw S + form SD,Sy + solve (mean of 5)")
    plt.axhline(t_b, color="r", ls="--", label=f"exact solve (part a): {t_b:.2f}s")
    plt.xscale("log"); plt.xlabel("sketch size m"); plt.ylabel("time (s)"); plt.ylim(bottom=0)
    plt.title("Q2(c): running time"); plt.legend(fontsize=8)
    savefig("q2c_time_vs_m.png")

    v = D @ b - y
    nv2 = float(v @ v)
    ratios = {}
    dd = {}
    for m in MS_D:
        out = np.empty(N_SKETCH_D)
        for k in range(N_SKETCH_D):
            rng = np.random.default_rng([SEED, 20, m, k])
            h, sg = draw_countsketch_hash(n, m, rng)
            Sv = np.zeros(m)
            np.add.at(Sv, h, sg * v)
            out[k] = float(Sv @ Sv) / nv2
        ratios[m] = out
        theory = float(np.sqrt(2.0 / m * (1.0 - np.sum(v ** 4) / nv2 ** 2)))   # exact sd of |Sv|^2/|v|^2
        dd[m] = {"mean": out.mean(), "std": out.std(ddof=1), "min": out.min(), "max": out.max(),
                 "theory_std": theory, "approx_sqrt_2_over_m": float(np.sqrt(2.0 / m))}
        print(f"(d) m={m}: mean={out.mean():.4f} sd={out.std(ddof=1):.4f} (theory {theory:.4f})", flush=True)
    dd["slope_std_vs_m"] = float(np.polyfit(np.log(MS_D), np.log([dd[m]["std"] for m in MS_D]), 1)[0])
    res["d"] = dd
    np.savez_compressed(os.path.join(OUT, "q2d_samples.npz"), **{f"m{m}": ratios[m] for m in MS_D})

    fig, axs = plt.subplots(1, 3, figsize=(11, 3.4))
    for ax, m in zip(axs, MS_D):
        ax.hist(ratios[m], bins=20, color="#7fa6d8", edgecolor="k")
        ax.axvline(1, color="r", ls="--"); ax.set_title(f"m = {m}")
        ax.set_xlabel("|Sv|^2 / |v|^2"); ax.set_ylabel("count")
    plt.suptitle("Q2(d): 100 CountSketches each (own x-range per panel)")
    savefig("q2d_hist_panels.png")
    lo_, hi_ = min(ratios[m].min() for m in MS_D), max(ratios[m].max() for m in MS_D)
    plt.figure(figsize=(7, 4))
    bins = np.linspace(lo_, hi_, 40)
    for m, col in zip(MS_D, ["#d95f02", "#1b9e77", "#7570b3"]):
        plt.hist(ratios[m], bins=bins, alpha=.55, label=f"m = {m}", color=col)
    plt.axvline(1, color="k", ls="--"); plt.xlabel("|Sv|^2 / |v|^2"); plt.ylabel("count"); plt.legend()
    plt.title("Q2(d): same histograms on a common x-axis")
    savefig("q2d_hist_common_axis.png")

    sub = np.random.default_rng([SEED, 30]).choice(n, SUBSET, replace=False)   
    Dp, yp = D[sub], y[sub]
    t0 = tic()
    bp = np.linalg.lstsq(Dp, yp, rcond=None)[0]
    t_bp = tic() - t0
    loss_bp = loss(Dp, yp, bp)
    ero = []
    for rep in range(REPS):
        # (i) CountSketch
        rng = np.random.default_rng([SEED, 31, rep])
        t0 = tic()
        h, sg = draw_countsketch_hash(SUBSET, M_E, rng)
        SD, Sy = countsketch_apply(Dp, yp, h, sg, M_E)
        t_cs = tic() - t0
        t0 = tic(); a = np.linalg.lstsq(SD, Sy, rcond=None)[0]; ts_cs = tic() - t0
        ero.append({"method": "CountSketch", "rep": rep, "t_sketch": t_cs, "t_solve": ts_cs,
                    "ratio": loss(Dp, yp, a) / loss_bp})
        # (ii) dense Gaussian
        rng = np.random.default_rng([SEED, 32, rep])
        t0 = tic()
        S = rng.standard_normal((M_E, SUBSET)) / np.sqrt(M_E)
        SD = S @ Dp
        Sy = S @ yp
        t_dn = tic() - t0
        del S
        t0 = tic(); a = np.linalg.lstsq(SD, Sy, rcond=None)[0]; ts_dn = tic() - t0
        ero.append({"method": "Dense Gaussian", "rep": rep, "t_sketch": t_dn, "t_solve": ts_dn,
                    "ratio": loss(Dp, yp, a) / loss_bp})
        print(f"(e) rep={rep}: CS t={t_cs:.3f}s ratio={ero[-2]['ratio']:.5f} | dense t={t_dn:.3f}s ratio={ero[-1]['ratio']:.5f}",
              flush=True)
    edf = pd.DataFrame(ero)
    edf.to_csv(os.path.join(OUT, "q2e_runs.csv"), index=False)
    e = {"subset_size": SUBSET, "m": M_E, "loss_b_prime": loss_bp, "time_b_prime": t_bp}
    for meth in ["CountSketch", "Dense Gaussian"]:
        g = edf[edf.method == meth]
        e[meth] = {"t_sketch_mean": g.t_sketch.mean(), "t_sketch_std": g.t_sketch.std(ddof=1),
                   "t_solve_mean": g.t_solve.mean(), "ratio_mean": g.ratio.mean(),
                   "ratio_std": g.ratio.std(ddof=1), "ratio_min": g.ratio.min(), "ratio_max": g.ratio.max()}
    e["dense_S_full_D_gigabytes_float64"] = M_E * n * 8 / 1e9
    e["dense_S_subset_megabytes_float64"] = M_E * SUBSET * 8 / 1e6
    e["flops_dense_full_D"] = 2.0 * M_E * n * d
    e["adds_countsketch_full_D"] = float(n) * d
    res["e"] = e
    save_json(res, "q2_results.json")
    print("Q2 done.", flush=True)


if __name__ == "__main__":
    main()
