
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

from common import (SEED, FIG, OUT, ensure_dirs, tic, save_json, env_info, load_kdd, build_D,
                    cost_centres, cost_partition, cluster_means, project)
import os

K = 15
MS = [5, 10, 15, 20, 25]
REPS = 5
N_PAIRS = 10_000
N_DRAWS_E = 20


def savefig(name):
    plt.tight_layout()
    plt.savefig(os.path.join(FIG, name), dpi=200)
    plt.close()


def main():
    ensure_dirs()
    print("loading data ...", flush=True)
    kdd = load_kdd()
    D, summ = build_D(kdd)
    n, d = D.shape
    save_json(summ, "data_summary.json")
    print(f"D: n={n}, d={d}, dtype={D.dtype}", flush=True)
    res = {"n": n, "d": d, "env": env_info(), "K": K}

    t0 = tic()
    kmD = KMeans(n_clusters=K, n_init=5, random_state=SEED).fit(D)
    t_a = tic() - t0
    B = kmD.cluster_centers_
    labelsD = kmD.labels_.astype(np.int64)
    cost_B = cost_centres(D, B)
    cost_D_CD = cost_partition(D, labelsD, K)          # cost_D(C_D), used in (e)
    res["a"] = {"cost_DB": cost_B, "time_sec": t_a, "sklearn_inertia": float(kmD.inertia_),
                "cost_D_of_partition_CD": cost_D_CD,
                "cluster_sizes": np.bincount(labelsD, minlength=K).tolist(),
                "n_iter": int(kmD.n_iter_)}
    print(f"(a) cost(D,B)={cost_B:.6g}  time={t_a:.2f}s", flush=True)

    rows = []
    for m in MS:
        for rep in range(REPS):
            rng = np.random.default_rng([SEED, 1, m, rep])
            t0 = tic()
            A = rng.standard_normal((m, d)) / np.sqrt(m)           # N(0,1/m) entries
            tA = tic() - t0
            rs = int(rng.integers(0, 2 ** 31 - 1))                 # seed for this k-means run
            A32 = A.astype(np.float32)
            t0 = tic()
            E = D @ A32.T                                          # E = D A^T  (row i = A D_i)
            tE = tic() - t0
            t0 = tic()
            kmE = KMeans(n_clusters=K, n_init=5, random_state=rs).fit(E)
            tK = tic() - t0
            labels = kmE.labels_.astype(np.int64)
            t0 = tic()
            Bhat, _ = cluster_means(D, labels, K)
            tB = tic() - t0
            c_hat = cost_centres(D, Bhat)
            c_part = cost_partition(D, labels, K)                  # cost_D(C_E) (no re-assignment)
            t0 = tic()
            Bplus = (np.linalg.pinv(A) @ kmE.cluster_centers_.astype(np.float64).T).T
            tP = tic() - t0
            c_plus = cost_centres(D, Bplus)
            rows.append({"m": m, "rep": rep, "cost_hat": c_hat, "ratio_hat": c_hat / cost_B,
                         "cost_plus": c_plus, "ratio_plus": c_plus / cost_B,
                         "cost_D_of_CE": c_part, "ratio_part": c_part / cost_B,
                         "t_drawA": tA, "t_E": tE, "t_kmeans": tK, "t_E_plus_kmeans": tE + tK,
                         "t_Bhat": tB, "t_pinv_map": tP, "t_total_with_A_and_Bhat": tA + tE + tK + tB,
                         "kmeans_inertia_E": float(kmE.inertia_)})
            print(f"  m={m:2d} rep={rep}: ratio_hat={c_hat / cost_B:.4f} ratio_plus={c_plus / cost_B:.4f} "
                  f"t(E+km)={tE + tK:.2f}s", flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT, "q1_runs.csv"), index=False)
    agg = {}
    for m in MS:
        g = df[df.m == m]
        agg[m] = {
            "ratio_mean": g.ratio_hat.mean(), "ratio_min": g.ratio_hat.min(), "ratio_max": g.ratio_hat.max(),
            "ratio_plus_mean": g.ratio_plus.mean(), "ratio_plus_min": g.ratio_plus.min(),
            "ratio_plus_max": g.ratio_plus.max(),
            "ratio_part_mean": g.ratio_part.mean(),
            "n_below_1": int((g.ratio_hat < 1).sum()), "n_below_1_plus": int((g.ratio_plus < 1).sum()),
            "time_mean": g.t_E_plus_kmeans.mean(), "time_std": g.t_E_plus_kmeans.std(ddof=1),
            "t_E_mean": g.t_E.mean(), "t_kmeans_mean": g.t_kmeans.mean(),
            "t_drawA_mean": g.t_drawA.mean(), "t_Bhat_mean": g.t_Bhat.mean(),
            "time_total_mean": g.t_total_with_A_and_Bhat.mean(),
        }
    res["bcd"] = agg

    x = np.arange(len(MS))
    plt.figure(figsize=(6.4, 4))
    mean = np.array([agg[m]["ratio_mean"] for m in MS])
    lo = np.array([agg[m]["ratio_min"] for m in MS])
    hi = np.array([agg[m]["ratio_max"] for m in MS])
    plt.bar(x, mean, yerr=[mean - lo, hi - mean], capsize=4, color="#7fa6d8", label="mean (bar), min/max (whiskers)")
    for i, m in enumerate(MS):
        plt.scatter(np.full(REPS, i) + np.linspace(-0.15, 0.15, REPS), df[df.m == m].ratio_hat,
                    s=14, color="k", zorder=3, label="individual runs" if i == 0 else None)
    plt.axhline(1, color="r", ls="--", lw=1, label="ratio = 1")
    plt.xticks(x, MS); plt.xlabel("projected dimension m"); plt.ylabel("cost(D, B_hat) / cost(D, B)")
    plt.title("Q1(b): k-means cost ratio using B_hat"); plt.legend(fontsize=8)
    savefig("q1b_ratio_vs_m.png")

    plt.figure(figsize=(7, 4))
    w = 0.38
    for off, key, lab, col in [(-w / 2, "ratio", "B_hat (mean of D-rows)", "#7fa6d8"),
                               (w / 2, "ratio_plus", "B+ = pinv(A) a", "#e59a6b")]:
        mu = np.array([agg[m][key + "_mean"] for m in MS])
        l_ = np.array([agg[m][key + "_min"] for m in MS])
        h_ = np.array([agg[m][key + "_max"] for m in MS])
        plt.bar(x + off, mu, w, yerr=[mu - l_, h_ - mu], capsize=3, label=lab, color=col)
    plt.axhline(1, color="r", ls="--", lw=1)
    if max(agg[m]["ratio_plus_max"] for m in MS) / max(1e-12, min(agg[m]["ratio_min"] for m in MS)) > 20:
        plt.yscale("log")
    plt.xticks(x, MS); plt.xlabel("projected dimension m"); plt.ylabel("cost ratio vs cost(D, B)")
    plt.title("Q1(c): B_hat versus B+"); plt.legend(fontsize=8)
    savefig("q1c_hat_vs_plus.png")

    plt.figure(figsize=(6.4, 4))
    tm = np.array([agg[m]["time_mean"] for m in MS])
    ts = np.array([agg[m]["time_std"] for m in MS])
    plt.errorbar(MS, tm, yerr=ts, marker="o", capsize=4, label="compute E + k-means on E (mean of 5, +/- 1 sd)")
    plt.axhline(t_a, color="r", ls="--", label=f"k-means on D (part a): {t_a:.1f}s")
    plt.xlabel("projected dimension m"); plt.ylabel("wall-clock time (s)"); plt.ylim(bottom=0)
    plt.title("Q1(d): running time"); plt.legend(fontsize=8)
    savefig("q1d_time_vs_m.png")

    rng = np.random.default_rng([SEED, 2])
    I, L = [], []
    while sum(len(a) for a in I) < N_PAIRS:
        i = rng.integers(0, n, size=3 * N_PAIRS)
        l = rng.integers(0, n, size=3 * N_PAIRS)
        ok = (i != l) & (D[i] != D[l]).any(axis=1)                  # require i != l and D_i != D_l
        I.append(i[ok]); L.append(l[ok])
    I = np.concatenate(I)[:N_PAIRS]; L = np.concatenate(L)[:N_PAIRS]
    diff = D[I].astype(np.float64) - D[L].astype(np.float64)
    dd = (diff ** 2).sum(1)
    assert (dd > 0).all()
    pair_ratios, cost_ratios = {}, {}
    for m in MS:
        A = np.random.default_rng([SEED, 3, m]).standard_normal((m, d)) / np.sqrt(m)   # one draw
        pair_ratios[m] = ((diff @ A.T) ** 2).sum(1) / dd           # |E_i-E_l|^2/|D_i-D_l|^2
        cr = []
        for r in range(N_DRAWS_E):                                 # 20 independent draws
            A = np.random.default_rng([SEED, 4, m, r]).standard_normal((m, d)) / np.sqrt(m)
            E64 = project(D, A, np.float64)
            cr.append(cost_partition(E64, labelsD, K) / cost_D_CD)
        cost_ratios[m] = np.array(cr)
        print(f"(e) m={m}: pair ratio sd={pair_ratios[m].std():.4f}  cost ratio sd={cost_ratios[m].std(ddof=1):.5f}",
              flush=True)
    e = {}
    for m in MS:
        p, c = pair_ratios[m], cost_ratios[m]
        q = lambda a: np.percentile(a, [25, 75])
        e[m] = {"pair_mean": p.mean(), "pair_std": p.std(ddof=1), "pair_iqr": np.subtract(*q(p)[::-1]),
                "pair_min": p.min(), "pair_max": p.max(), "pair_theory_std_sqrt_2_over_m": np.sqrt(2 / m),
                "cost_mean": c.mean(), "cost_std": c.std(ddof=1), "cost_iqr": np.subtract(*q(c)[::-1]),
                "cost_min": c.min(), "cost_max": c.max()}
    ms = np.array(MS, float)
    e["slope_pair_std_vs_m"] = float(np.polyfit(np.log(ms), np.log([e[m]["pair_std"] for m in MS]), 1)[0])
    e["slope_cost_std_vs_m"] = float(np.polyfit(np.log(ms), np.log([e[m]["cost_std"] for m in MS]), 1)[0])
    e["n_pairs"] = N_PAIRS; e["n_draws"] = N_DRAWS_E
    res["e"] = e
    np.savez_compressed(os.path.join(OUT, "q1e_samples.npz"),
                        **{f"pair_{m}": pair_ratios[m] for m in MS}, **{f"cost_{m}": cost_ratios[m] for m in MS})

    def boxfig(ylim=None, only_cost=False, name=""):
        plt.figure(figsize=(8, 4.5))
        pos = np.arange(len(MS))
        if not only_cost:
            b1 = plt.boxplot([pair_ratios[m] for m in MS], positions=pos - 0.2, widths=0.34, patch_artist=True,
                             flierprops=dict(marker=".", markersize=2, alpha=.3))
            for b in b1["boxes"]:
                b.set_facecolor("#9ecae1")
        b2 = plt.boxplot([cost_ratios[m] for m in MS], positions=pos + (0 if only_cost else 0.2), widths=0.34,
                         patch_artist=True, flierprops=dict(marker="o", markersize=3))
        for b in b2["boxes"]:
            b.set_facecolor("#fdae6b")
        plt.axhline(1, color="r", ls="--", lw=1)
        plt.xticks(pos, MS); plt.xlabel("projected dimension m"); plt.ylabel("ratio")
        if ylim: plt.ylim(*ylim)
        import matplotlib.patches as mp
        h = [mp.Patch(color="#fdae6b", label="(ii) cost_E(C_D)/cost_D(C_D), 20 draws of A")]
        if not only_cost:
            h.insert(0, mp.Patch(color="#9ecae1", label="(i) |E_i-E_l|^2/|D_i-D_l|^2, 10^4 pairs, 1 draw of A"))
        plt.legend(handles=h, fontsize=8, loc="upper right")
        plt.title("Q1(e): distortion of pairwise distances vs distortion of the k-means cost" + name)
        savefig("q1e_boxplots.png" if not only_cost else "q1e_boxplots_zoom_cost.png")
    boxfig()
    boxfig(only_cost=True, name=" (zoom on (ii))")

    save_json(res, "q1_results.json")
    print("Q1 done.", flush=True)


if __name__ == "__main__":
    main()
