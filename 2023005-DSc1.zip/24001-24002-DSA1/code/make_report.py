"""Builds the PDF of answers (all tables, plots and comments) from results/ produced by q1_kmeans.py and
q2_regression.py.   Usage:
    python make_report.py --rolls 24001 24002 [--names "A B" "C D"] [--discussed "group X, group Y"] [--urls "https://..."]
Comments are generated from the actual numbers (so they always match the tables); READ THEM and edit/extend
them if you want, they are plain python strings in the q1_text / q2_text functions below.
"""
import argparse
import datetime
import os

import matplotlib
import numpy as np
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table,
                                TableStyle)

OUT = os.environ.get("DSA_OUT", "results")
FIG = os.path.join(OUT, "figs")

# ---------------------------------------------------------------- fonts (DejaVu ships with matplotlib)
fdir = os.path.join(matplotlib.get_data_path(), "fonts", "ttf")
for nm, fn in [("DejaVu", "DejaVuSans.ttf"), ("DejaVu-Bold", "DejaVuSans-Bold.ttf"),
               ("DejaVu-Oblique", "DejaVuSans-Oblique.ttf"), ("DejaVu-BoldOblique", "DejaVuSans-BoldOblique.ttf")]:
    pdfmetrics.registerFont(TTFont(nm, os.path.join(fdir, fn)))
pdfmetrics.registerFontFamily("DejaVu", normal="DejaVu", bold="DejaVu-Bold", italic="DejaVu-Oblique",
                              boldItalic="DejaVu-BoldOblique")
ss = getSampleStyleSheet()
BODY = ParagraphStyle("body", parent=ss["BodyText"], fontName="DejaVu", fontSize=9, leading=12.5, spaceAfter=5)
SMALL = ParagraphStyle("small", parent=BODY, fontSize=7.5, leading=10)
H1 = ParagraphStyle("h1", parent=ss["Heading1"], fontName="DejaVu-Bold", fontSize=15, spaceBefore=8, spaceAfter=6)
H2 = ParagraphStyle("h2", parent=ss["Heading2"], fontName="DejaVu-Bold", fontSize=11.5, spaceBefore=10, spaceAfter=4)
TITLE = ParagraphStyle("title", parent=H1, fontSize=19, alignment=1, spaceAfter=10)
WARN = ParagraphStyle("warn", parent=BODY, textColor=colors.red, fontName="DejaVu-Bold", fontSize=11)
CM = ParagraphStyle("cm", parent=BODY, leftIndent=8, borderPadding=4, backColor=colors.HexColor("#f4f7fb"))


def P(t, st=BODY):
    return Paragraph(t, st)


def f(x, nd=4):
    if x is None:
        return "-"
    x = float(x)
    if x != 0 and (abs(x) >= 1e6 or abs(x) < 1e-3):
        return f"{x:.4e}"
    return f"{x:.{nd}f}"


def g(x):
    return "-" if x is None else f"{float(x):.7g}"


def T(rows, widths=None, fs=7.5):
    """Table that always fits the page: header cells wrap, column widths are fitted to the content."""
    avail = 17.0 * cm
    hs = ParagraphStyle("th", fontName="DejaVu-Bold", fontSize=fs, leading=fs + 1.5, alignment=2)
    rows = [[Paragraph(str(c), hs) for c in rows[0]]] + [[str(c) for c in r] for r in rows[1:]]
    if widths is None:
        ncol = len(rows[0])
        widths = []
        for j in range(ncol):
            body = max([pdfmetrics.stringWidth(r[j], "DejaVu", fs) for r in rows[1:]] + [0])
            words = max(pdfmetrics.stringWidth(w, "DejaVu-Bold", fs) for w in rows[0][j].text.split()) if rows[0][j].text.split() else 0
            widths.append(max(body, words) + 12)
        tot = sum(widths)
        if tot > avail:
            widths = [w * avail / tot for w in widths]
    t = Table(rows, colWidths=widths, repeatRows=1, hAlign="LEFT")
    t.setStyle(TableStyle([("FONT", (0, 0), (-1, -1), "DejaVu", fs),
                           ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
                           ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8eef7")),
                           ("ALIGN", (0, 0), (-1, -1), "RIGHT"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                           ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
                           ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3)]))
    return t


def IMG(name, width=15.5 * cm):
    path = os.path.join(FIG, name)
    w, h = ImageReader(path).getSize()
    return Image(path, width=width, height=width * h / w)


def J(name):
    import json
    with open(os.path.join(OUT, name)) as fh:
        return json.load(fh)


# ================================================================ Q1 text
def q1_text(R):
    a, agg, e = R["a"], R["bcd"], R["e"]
    MS = sorted(int(k) for k in agg)
    mean = [agg[str(m)]["ratio_mean"] for m in MS]
    nb = sum(agg[str(m)]["n_below_1"] for m in MS)
    runs = pd.read_csv(os.path.join(OUT, "q1_runs.csv"))
    out = {}
    # ---- (b)
    s = "Mean ratio cost(D,B̂)/cost(D,B) (min–max over 5 runs): " + "; ".join(
        f"m={m}: {f(agg[str(m)]['ratio_mean'])} ({f(agg[str(m)]['ratio_min'])}–{f(agg[str(m)]['ratio_max'])})" for m in MS) + "."
    mono = all(np.diff(mean) <= 0)
    s += (" The mean ratio " + ("decreases monotonically" if mono else "decreases overall (not strictly monotonically — with only "
          "5 runs per m the noise is comparable to the step between neighbouring m)") +
          f" from {f(mean[0])} at m={MS[0]} to {f(mean[-1])} at m={MS[-1]}, and the run-to-run spread "
          f"(max−min) goes from {f(agg[str(MS[0])]['ratio_max'] - agg[str(MS[0])]['ratio_min'])} to "
          f"{f(agg[str(MS[-1])]['ratio_max'] - agg[str(MS[-1])]['ratio_min'])}.")
    s2 = ("This is what the JL lemma predicts: a random projection to m dimensions distorts squared distances by a factor "
          "1±ε with ε of order 1/√m (see (e)), so the k-means cost of any fixed clustering computed in R^m is "
          "within (1±ε) of its cost in R^d, and clusterings that are good in R^m stay good in R^d. Larger m ⇒ smaller ε ⇒ "
          "ratio closer to 1. For k-means it is known that m = O(k/ε²) dimensions suffice for this (Cohen et al., 2015; "
          "O(log k/ε²) by Makarychev et al., 2019); here k = 15 and m ≤ 25, i.e. m is of the order of k only, so an "
          "excess cost clearly above 1 for small m is expected, and it shrinks as m grows. B̂ is always computed from the "
          "original rows of D, so it is a legitimate set of centres in R^d.")
    if nb > 0:
        mn = runs.ratio_hat.min()
        s3 = (f"<b>Ratios below 1.</b> {nb} of the 25 runs have ratio &lt; 1 (smallest {f(mn)}). This is not a contradiction of JL "
              "or of optimality: B is not the optimum of the k-means problem, only the best of 5 Lloyd runs (a local "
              "optimum; k-means is NP-hard and Lloyd's algorithm is initialisation dependent). Clustering in the projected space "
              "is an alternative route to another local optimum; B̂ is evaluated with nearest-centre assignment (which can only "
              "lower the cost of the partition C_E), so whenever C_E happens to lie in a better basin than C_D the ratio drops "
              "below 1. It means ‘cost(D,B) was not the global minimum’, and shows that the ratio compares two heuristics "
              "rather than an algorithm against OPT.")
    else:
        s3 = ("<b>Ratios below 1.</b> None of the 25 runs gave a ratio below 1 in our experiment. It would not be impossible: "
              "B is only the best of 5 Lloyd runs (a local optimum, not the global minimum), so B̂ obtained from the clustering "
              "found on E could land in a better local optimum and give a ratio &lt; 1; a ratio below 1 would signal "
              "that cost(D,B) is not OPT, not that JL ‘improves’ k-means.")
    out["b"] = [s, s2, s3]
    # ---- (c)
    mh = [agg[str(m)]["ratio_mean"] for m in MS]
    mp = [agg[str(m)]["ratio_plus_mean"] for m in MS]
    better = all(h <= p for h, p in zip(mh, mp))
    s = ("Mean ratios, B̂ vs B⁺: " + "; ".join(f"m={m}: {f(h)} vs {f(p)}" for m, h, p in zip(MS, mh, mp)) + ".")
    if better:
        s += (" B̂ has the lower mean ratio for every m, and B⁺ is worse by a large factor. ")
    else:
        s += (" B̂ is not the better choice for every m in our runs (see table); ")
    s += ("The reason is geometric: A⁺A is the orthogonal projector onto the m-dimensional row space of A, so B⁺ = A⁺a = A⁺A·(a "
          "lifted) only contains the part of the cluster centre that lies in an m-dimensional subspace. The remaining d−m "
          "dimensions of the true centroid are lost (the centres are also shrunk towards the origin of that subspace, "
          "although the data lie in [0,1]^d), so B⁺ can be far from the data. B̂ instead uses the clustering found in R^m to average the "
          "original d-dimensional rows, so it recovers all d coordinates of each cluster mean.")
    s2 = ("<b>Choice:</b> " + ("we would use B̂. " if better else "we would use whichever has the lower ratio, which in the table is B̂ for most m. ") +
          "Its price is one extra pass over D (O(nd) to average rows, measured in (d) as t_B̂) — small next to k-means. B⁺ would only be "
          "preferable if D is no longer available (only E and A are stored), in which case it is the only way to get centres in R^d, "
          "but it must be expected to give a much larger cost.")
    out["c"] = [s, s2]
    # ---- (d)
    ta = a["time_sec"]
    tm = [agg[str(m)]["time_mean"] for m in MS]
    sp = [ta / t for t in tm]
    s = (f"k-means on D takes {f(ta, 2)} s. Mean time of (compute E + k-means on E): " +
         "; ".join(f"m={m}: {f(t, 2)} s (speed-up ×{f(x, 1)})" for m, t, x in zip(MS, tm, sp)) + ".")
    corr = np.corrcoef(MS, tm)[0, 1]
    dm = [R["d"] / m for m in MS]
    tb = [agg[str(m)]["t_Bhat_mean"] / agg[str(m)]["time_mean"] for m in MS]
    s2 = (f"The time grows with m (correlation of time with m: {f(corr, 3)}), as expected: each Lloyd iteration costs O(n·k·m) distance "
          f"evaluations versus O(n·k·d) on D (d = {R['d']}); computing E = DAᵀ costs O(n·d·m) once and is small (≤ {f(max(agg[str(m)]['t_E_mean'] for m in MS), 3)} s). "
          f"The measured speed-up ({f(min(sp), 1)}–{f(max(sp), 1)}×) is much smaller than the ratio d/m of the per-iteration arithmetic "
          f"({', '.join(f(x, 1) for x in dm)}× for m = {', '.join(map(str, MS))}): the total time also contains costs that do not shrink with m — "
          "k-means++ initialisation and the 5 restarts, per-iteration overhead of sklearn (label/centre updates, memory traffic over n rows) and the number of Lloyd iterations, "
          "which differs between runs. The extra pass that forms B̂ takes "
          f"{f(100 * min(tb), 1)}–{f(100 * max(tb), 1)}% of the (E + k-means) time; drawing A is negligible. "
          "Totals including A and B̂ are in the last column of the table. Times depend on the machine / number of threads (see Reproducibility).")
    out["d"] = [s, s2]
    # ---- (e)
    sp_ = [e[str(m)]["pair_std"] for m in MS]
    sc_ = [e[str(m)]["cost_std"] for m in MS]
    iq_p = [e[str(m)]["pair_iqr"] for m in MS]
    iq_c = [e[str(m)]["cost_iqr"] for m in MS]
    smaller = all(c < p for c, p in zip(sc_, sp_)) and all(c < p for c, p in zip(iq_c, iq_p))
    s = ("Std. dev. of (i) pairwise ratios: " + "; ".join(f"m={m}: {f(x)}" for m, x in zip(MS, sp_)) +
         ". Std. dev. of (ii) cost ratios: " + "; ".join(f"m={m}: {f(x, 5)}" for m, x in zip(MS, sc_)) +
         ". Means: (i) " + ", ".join(f(e[str(m)]["pair_mean"], 3) for m in MS) + "; (ii) " +
         ", ".join(f(e[str(m)]["cost_mean"], 3) for m in MS) + " — both are centred near 1 (E‖Ax‖² = ‖x‖² for the N(0,1/m) matrix); the deviations of the (i) means from 1 come from the single draw of A.")
    try:
        z = np.load(os.path.join(OUT, "q1e_samples.npz"))
        p5 = np.round(z[f"pair_{MS[0]}"], 9)
        vals, cnt = np.unique(p5, return_counts=True)
        top = np.sort(cnt)[::-1][:2]
        dup_txt = (f"In our sample, {int(top[0])} of the {len(p5)} pairs have exactly the same ratio, and another {int(top[1])} share a second identical value "
                   f"(only {len(vals)} distinct values among {len(p5)} pairs): these pairs have identical difference vectors D_i−D_l (typically a change of one or two "
                   "binary/one-hot features, very frequent in KDD), so for a given A they are distorted identically. ")
    except Exception:
        dup_txt = ""
    s2 = ("<b>Spread.</b> " + ("The cost ratio (ii) has the smaller spread for every m (both std and IQR). " if smaller else
          "In our data the cost ratio (ii) does not have the smaller spread for every m (see table). ") +
          "For a <i>fixed</i> pair and a random A, ‖A(D_i−D_l)‖²/‖D_i−D_l‖² is distributed as χ²_m/m, with std √(2/m) (column '√(2/m)'): "
          "an individual pair can be distorted a lot (min–max in the table). The measured std of (i) is below √(2/m), because in (i) there is only <b>one</b> draw of A "
          "and the 10⁴ pairs are not independent samples of that distribution. " + dup_txt +
          "The k-means cost of a fixed clustering aggregates the squared distances of n = " + str(R["n"]) + " points to their cluster means; "
          "the distortions of the many different directions partly average out, so the ratio is far more concentrated. "
          "That is why clustering survives much smaller m than the worst-case guarantee for each individual pair.")
    sl_p, sl_c = R["e"]["slope_pair_std_vs_m"], R["e"]["slope_cost_std_vs_m"]
    mono_p = all(np.diff(sp_) <= 0)
    mono_c = all(np.diff(sc_) <= 0)
    s3 = (f"<b>Change with m.</b> Both spreads tend to shrink as m grows, but not cleanly. (i): std goes from {f(sp_[0], 3)} (m={MS[0]}) to {f(sp_[-1], 3)} (m={MS[-1]}) "
          f"({'monotonically' if mono_p else 'not monotonically, because of the single draw of A and the repeated pairs above'}); the fitted log-log slope is {f(sl_p, 3)}, "
          "shallower than the −0.5 of √(2/m) for the same reason. Also the mean of (i) fluctuates around 1 (" + ", ".join(f(e[str(m)]["pair_mean"], 3) for m in MS) +
          ") — this is the error of the single draw of A, shared by all pairs, not sampling noise over pairs. "
          f"(ii): std goes from {f(sc_[0], 3)} to {f(sc_[-1], 3)} ({'monotonically' if mono_c else 'not monotonically'}, slope {f(sl_c, 3)}; "
          "only 20 draws per m, so each std has ≈ 16% relative uncertainty, which is of the order of the differences between m = 15, 20 and 25). "
          f"At every m the cost ratio's spread is much smaller than the pairwise one (at m = {MS[0]}: {f(sc_[0], 3)} vs {f(sp_[0], 3)}).")
    out["e"] = [s, s2, s3]
    return out


# ================================================================ Q2 text
def q2_text(R, S):
    a, agg, d, e = R["a"], R["bc"], R["d"], R["e"]
    MS = sorted(int(k) for k in agg)
    r = a["rank_D"]
    dd = R["d"] if False else None
    out = {}
    n_cols = S["d"]
    deficiency = n_cols - r
    grp = S["onehot_groups"]
    full = sum(1 for v in grp.values() if v["dummies_kept"] == v["dummies_total"] and v["dummies_total"] > 0)
    expl = (f"D has d = {n_cols} columns but rank(D) = {r}, i.e. it is rank-deficient by {deficiency}. ")
    if deficiency == full - 1 and full >= 2:
        expl += (f"This is explained by the one-hot encoding: with all dummy columns of the {full} categorical features kept, the dummies of each "
                 f"feature sum to 1 in every row, which gives {full}−1 = {full - 1} independent linear dependences "
                 "(sum of protocol_type dummies = sum of service dummies = sum of flag dummies); there is no intercept column, so this is rank loss, not an error. ")
    else:
        expl += ("Part of the deficiency is explained by the one-hot encoding (the dummies of each categorical feature sum to 1 in every row, "
                 "giving linear dependences among the three groups); the rest comes from other exact dependences in the data. ")
    expl += ("numpy.linalg.lstsq (SVD based) returns the minimum-norm minimiser in this case; the minimum value of the loss, "
             "and hence every loss/ratio reported, is unaffected by the rank deficiency.")
    out["a"] = [expl]
    # (b)
    below = [m for m in MS if m < r]
    above = [m for m in MS if m > r]
    Lb = a["loss_b"]
    runs = pd.read_csv(os.path.join(OUT, "q2_runs.csv"))
    s = ("Mean ratio Loss(D,y,ã)/Loss(D,y,b): " + "; ".join(f"m={m}: {f(agg[str(m)]['ratio_mean'], 4)} "
          f"({f(agg[str(m)]['ratio_min'], 4)}–{f(agg[str(m)]['ratio_max'], 4)})" for m in MS) + ". "
         f"All ratios are ≥ 1 (smallest over all 35 runs: {f(runs.ratio.min(), 6)}), as they must be because b is the least-squares minimiser.")
    out["b1"] = s
    if below:
        mx = max(agg[str(m)]["sketched_max"] for m in below)
        s = (f"<b>Below m = rank(D) = {r}</b> (m = {', '.join(map(str, below))}): the sketched system SD·a = Sy has m &lt; r rows, so SD "
             "(of full row rank m with probability 1) can fit Sy <i>exactly</i>; lstsq returns an interpolating minimum-norm "
             f"solution and the sketched loss is numerically zero (largest value observed {f(mx)}, versus Loss(D,y,b) = {f(Lb)}). "
             "The sketched loss therefore says nothing about quality, and the true loss of ã is far above the optimum: the sketch cannot "
             f"even preserve the column space of D (mean ratio {', '.join(f(agg[str(m)]['ratio_mean'], 3) for m in below)}). ")
    else:
        s = "No tested m lies below rank(D). "
    if len(below) >= 2:
        rb = [agg[str(m)]["ratio_mean"] for m in below]
        if rb[-1] > rb[0]:
            s += (f"Note that below the threshold the ratio is <b>not</b> monotone: it is larger at m = {below[-1]} ({f(rb[-1], 3)}) than at m = {below[0]} ({f(rb[0], 3)}). "
                  "This is the interpolation peak of minimum-norm least squares (‘double descent’): as m approaches rank(D) from below, SD becomes nearly square and "
                  "ill-conditioned, the interpolating solution has a large norm, and the true loss is worst around m ≈ r; it then falls as m grows beyond r. ")
    s2 = ""
    if above:
        gr = [(m, agg[str(m)]["ratio_mean"], agg[str(m)]["gaussian_reference_ratio"]) for m in above if agg[str(m)]["gaussian_reference_ratio"]]
        maxdev = max(abs(x / y - 1) for _, x, y in gr) if gr else float("nan")
        s2 = (f"<b>Above m = rank(D)</b> (m = {', '.join(map(str, above))}): the sketched loss becomes clearly positive and approaches Loss(D,y,b) "
              "as m grows (sketched loss / Loss(b): " + ", ".join(f"m={m}: {f(agg[str(m)]['sketched_over_loss_b_mean'], 4)}" for m in above) +
              "), in line with the factor (1−r/m) expected for a subspace-embedding sketch (" + ", ".join(f"{f(1 - r / m, 3)}" for m in above) +
              "). The ratio drops quickly just after the threshold and then slowly towards 1; its excess over 1 behaves like r/m — the measured means agree with the "
              f"Gaussian reference 1 + r/(m−r−1) within {f(100 * maxdev, 1)}% for all m > r + 1 (table), i.e. CountSketch behaves here like a dense Gaussian sketch, "
              "and the run-to-run variation is visible in the min/max bars. "
              f"At the largest m = {above[-1]} the mean ratio is {f(agg[str(above[-1])]['ratio_mean'], 4)}. "
              f"(Worst-case theory for CountSketch asks for m on the order of r²/ε² rows (Clarkson–Woodruff 2013; here r² ≈ {r * r}); in practice much smaller m already gives a good ratio.)")
    out["b2"] = [s, s2]
    # (c)
    tb = a["time_sec"]
    sp = {m: tb / agg[str(m)]["t_total"] for m in MS}
    s = (f"Exact least squares (a) takes {f(tb, 3)} s. Sketch pipeline (draw S + form SD, Sy + solve), mean of 5: " +
         "; ".join(f"m={m}: {f(agg[str(m)]['t_total'], 3)} s (×{f(sp[m], 2)})" for m in MS) + ".")
    faster = [m for m in MS if sp[m] > 1]
    s2 = ("The cost of forming SD is one pass over D (n·d signed additions) and does not depend on m; solving costs O(m·d²) and grows "
          "with m, whereas the exact solve costs O(n·d²) via the SVD. ")
    if len(faster) == len(MS):
        s2 += "The sketch is faster than the exact solve for every m tested; "
    elif faster:
        s2 += f"The sketch is faster than the exact solve for m = {', '.join(map(str, faster))} only; "
    else:
        s2 += ("In our run the sketch is <i>not</i> faster than the exact solve — the data matrix has only d ≈ " + str(n_cols) +
               " columns, so lstsq on D is already cheap in absolute terms and our pure-numpy np.add.at pass is not faster than LAPACK; ")
    s2 += ("the gain of sketching grows with n and d (it would matter for tall matrices that do not fit LAPACK's fast path or "
           "for streaming data, because the sketch is formed in one pass and needs only m×d memory). See the breakdown table for the dominant term at each m.")
    out["c"] = [s, s2]
    # (d)
    MD = [50, 500, 5000]
    sd = [d[str(m)]["std"] for m in MD]
    th = [d[str(m)]["theory_std"] for m in MD]
    s = ("Mean and std of ‖Sv‖²/‖v‖² over 100 CountSketches: " + "; ".join(
        f"m={m}: mean {f(d[str(m)]['mean'], 4)}, std {f(d[str(m)]['std'], 4)} (exact theory {f(d[str(m)]['theory_std'], 4)})" for m in MD) + ".")
    s2 = ("<b>Spread.</b> The mean stays ≈ 1 (E‖Sv‖² = ‖v‖², the sketch is unbiased) but the std shrinks as m grows: from "
          f"{f(sd[0], 4)} at m = 50 to {f(sd[2], 4)} at m = 5000, a factor {f(sd[0] / sd[2], 2)} for a 100× increase of m (a 1/√m law predicts a factor 10). "
          f"The fitted log-log slope is {f(d['slope_std_vs_m'], 3)} (theory −0.5). The histograms narrow around 1 accordingly. "
          "For CountSketch the exact variance is Var(‖Sv‖²) = (2/m)(‖v‖₂⁴ − ‖v‖₄⁴) (the pairs that collide in a bucket contribute a random-sign cross term), which we report as 'theory' "
          "and which matches the empirical std; it is smaller than the Gaussian value √(2/m) when the residual has a few large entries, since the ‖v‖₄⁴ term is subtracted.")
    out["d"] = [s, s2]
    # (e)
    cs, dn = e["CountSketch"], e["Dense Gaussian"]
    s = (f"Subset: {e['subset_size']} rows, m = {e['m']}; Loss(D',y',b') = {f(e['loss_b_prime'], 4)}. "
         f"CountSketch: time to draw S and form SD',Sy' = {f(cs['t_sketch_mean'], 4)} s (sd {f(cs['t_sketch_std'], 4)}), ratio = {f(cs['ratio_mean'], 4)} (sd {f(cs['ratio_std'], 4)}). "
         f"Dense Gaussian: time = {f(dn['t_sketch_mean'], 4)} s (sd {f(dn['t_sketch_std'], 4)}), ratio = {f(dn['ratio_mean'], 4)} (sd {f(dn['ratio_std'], 4)}).")
    t_ratio = dn["t_sketch_mean"] / max(cs["t_sketch_mean"], 1e-12)
    q_ratio = cs["ratio_mean"] / dn["ratio_mean"]
    if t_ratio > 1:
        s2 = (f"<b>Choice:</b> CountSketch for the full D. It builds SD in {f(t_ratio, 1)}× less time than the dense sketch and its accuracy "
              f"(mean ratio {f(cs['ratio_mean'], 4)} vs {f(dn['ratio_mean'], 4)}; CountSketch/dense = {f(q_ratio, 3)}) is "
              + ("comparable. " if abs(q_ratio - 1) < 0.05 else ("slightly worse. " if q_ratio > 1 else "not worse. ")))
    else:
        s2 = (f"<b>Choice:</b> in our run the dense sketch was not slower to form on the subset ({f(t_ratio, 2)}× the CountSketch time), but see the scaling argument below; "
              f"accuracy: CountSketch {f(cs['ratio_mean'], 4)} vs dense {f(dn['ratio_mean'], 4)}. ")
    s2 += (f"Scaling to the full D (n = {R['n']}): a dense S ∈ R^(m×n) with m = {e['m']} has {e['m'] * R['n']:.3g} entries, i.e. "
           f"{f(e['dense_S_full_D_gigabytes_float64'], 2)} GB in float64 (vs {f(e['dense_S_subset_megabytes_float64'], 0)} MB for the subset), and forming SD costs ≈ 2·m·n·d = "
           f"{e['flops_dense_full_D']:.3g} flops, whereas CountSketch never stores S, needs only n·d = {e['adds_countsketch_full_D']:.3g} signed additions "
           "(one pass, O(nnz(D))), and memory m×d. Since the quality of the two sketches is similar at this m, CountSketch is the sketch we would use on the full D.")
    out["e"] = [s, s2]
    return out


# ================================================================ report
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rolls", nargs="+", default=["rollno1", "rollno2"])
    ap.add_argument("--names", nargs="*", default=[])
    ap.add_argument("--discussed", default=None)
    ap.add_argument("--urls", default=None, help="override the default list of sources (plain text)")
    ap.add_argument("--synthetic", action="store_true", help="debug: mark the report as built from synthetic data")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    S, R1, R2 = J("data_summary.json"), J("q1_results.json"), J("q2_results.json")
    t1, t2 = q1_text(R1), q2_text(R2, S)
    out = args.out or os.path.join(OUT, f"{'-'.join(args.rolls)}-DSA1_answers.pdf")
    doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm,
                            bottomMargin=1.8 * cm, title="CSE558 Data Science - Assignment 1")
    st = []
    # ---------------- title
    st.append(P("CSE558 Data Science — Assignment 1", TITLE))
    st.append(P("Random projection (JL) on the KDD Cup 1999 data: k-means clustering and linear regression", ParagraphStyle("c", parent=BODY, alignment=1)))
    st.append(P(f"Group: {', '.join(args.rolls)}" + (f" ({'; '.join(args.names)})" if args.names else "") +
                f" &nbsp;|&nbsp; generated {datetime.date.today().isoformat()}", ParagraphStyle("c2", parent=BODY, alignment=1)))
    if args.synthetic:
        st.append(P("DEBUG BUILD: synthetic stand-in data, numbers are meaningless.", WARN))
    st.append(Spacer(1, 6))
    st.append(P("Sources", H2))
    if args.discussed:
        st.append(P(f"<b>Groups discussed with:</b> {args.discussed}"))
    if args.urls:
        st.append(P(f"<b>URLs / online material used:</b> {args.urls}"))
    else:
        links = [
            ("scikit-learn documentation, fetch_kddcup99", "https://scikit-learn.org/1.1/modules/generated/sklearn.datasets.fetch_kddcup99.html"),
            ("KDD Cup 1999 dataset description (UCI repository)", "https://archive.ics.uci.edu/dataset/130"),
            ("Cohen, Elder, Musco, Musco, Persu: Dimensionality Reduction for k-Means Clustering and Low Rank Approximation (arXiv:1410.6801)", "https://arxiv.org/abs/1410.6801"),
            ("Makarychev, Makarychev, Razenshteyn: Performance of Johnson-Lindenstrauss Transform for k-Means and k-Medians Clustering (arXiv:1811.03195)", "https://arxiv.org/abs/1811.03195"),
            ("Clarkson, Woodruff: Low Rank Approximation and Regression in Input Sparsity Time (arXiv:1207.6365)", "https://arxiv.org/abs/1207.6365"),
        ]
        st.append(P("<b>URLs / online material used:</b>"))
        for t, u in links:
            st.append(P(f"• {t}: <a href='{u}' color='blue'>{u}</a>", SMALL))
    st.append(P("Documentation consulted: numpy, scikit-learn and pandas reference pages. All code and text are our own."))
    st.append(P("Reproducibility", H2))
    env = R1["env"]
    st.append(P(f"One master seed SEED = {env['SEED']} is used. Every random object gets its own numpy Generator "
                "<font name='DejaVu'>np.random.default_rng([SEED, task_id, m, rep])</font> (A matrices, hash/sign vectors, pair sampling, row subset), "
                "and every KMeans call gets a fixed integer random_state (SEED for the run on D, a seed drawn from that generator for the runs on E). "
                f"Software: Python {env['python']}, numpy {env['numpy']}, pandas {env['pandas']}, scikit-learn {env['sklearn']}. "
                f"Machine: {env['platform']}, {env['cpu_count']} CPUs, BLAS/OpenMP thread pools {env['threadpools']}. "
                "Timings depend on the machine; all other numbers are reproducible (KMeans multi-threading may change floating-point "
                "summation order at the 1e-6 relative level). Scripts: common.py, q1_kmeans.py, q2_regression.py, make_report.py."))
    # ---------------- data
    st.append(P("Data matrix D", H1))
    st.append(P(f"Steps: (i) one-hot encode protocol_type, service, flag ({S['n_onehot_columns']} dummy columns) and convert the other "
                f"{S['n_numeric_columns']} features to float ({S['columns_before_dropping']} columns); (ii) drop every column constant over all rows: "
                f"{', '.join(S['dropped_constant_columns']) or 'none'}; (iii) min–max rescale every column to [0,1] (observed range of D: "
                f"[{f(S['min_value'], 1)}, {f(S['max_value'], 1)}]). Stored as {S['dtype']}."))
    st.append(T([["n (rows)", "d (columns)", "columns before dropping", "dropped", "distinct rows", "distinct labels", "attack fraction"],
                 [S["n"], S["d"], S["columns_before_dropping"], len(S["dropped_constant_columns"]), S["n_distinct_rows"],
                  S["n_distinct_labels"], f(S["attack_fraction"], 4)]]))
    st.append(Spacer(1, 4))
    st.append(P(f"<b>D ∈ R^(n×d) with n = {S['n']} and d = {S['d']}.</b>"))
    # ---------------- Q1
    st.append(PageBreak())
    st.append(P("Question 1 — JL for k-means clustering (k = 15)", H1))
    a = R1["a"]
    st.append(P("(a) k-means on D  [3 marks]", H2))
    st.append(T([["cost(D, B)", "wall-clock time (s)", "KMeans inertia_ (sklearn, for comparison)", "Lloyd iterations (best run)"],
                 [g(a["cost_DB"]), f(a["time_sec"], 3), g(a["sklearn_inertia"]), a["n_iter"]]]))
    st.append(P(f"Cluster sizes of C_D: {a['cluster_sizes']}. cost(D,B) is computed by our own function (nearest centre, exact float64 squared distances); "
                "KMeans(n_clusters=15, n_init=5, random_state=SEED).", SMALL))
    MS = sorted(int(k) for k in R1["bcd"])
    agg = R1["bcd"]
    runs = pd.read_csv(os.path.join(OUT, "q1_runs.csv"))
    st.append(P("(b) k-means on E = DAᵀ, centres B̂ = cluster means of D rows  [10 marks]", H2))
    rows = [["m", "mean ratio", "min ratio", "max ratio", "# runs < 1", "mean cost_D(C_E)/cost(D,B) (no reassign)"]]
    for m in MS:
        x = agg[str(m)]
        rows.append([m, f(x["ratio_mean"]), f(x["ratio_min"]), f(x["ratio_max"]), x["n_below_1"], f(x["ratio_part_mean"])])
    st.append(T(rows))
    st.append(Spacer(1, 4)); st.append(IMG("q1b_ratio_vs_m.png", 12.5 * cm))
    for t in t1["b"]:
        st.append(P(t, CM))
    rows = [["m", "run", "cost(D, B̂)", "ratio cost(D,B̂)/cost(D,B)"]]
    for _, r in runs.iterrows():
        rows.append([int(r.m), int(r.rep) + 1, g(r.cost_hat), f(r.ratio_hat, 5)])
    st.append(P("All 25 runs:", SMALL)); st.append(T(rows, fs=7))
    st.append(P("(c) Centres B⁺ = A⁺a  [4 marks]", H2))
    rows = [["m", "run", "ratio B̂ (from b)", "cost(D, B⁺)", "ratio B⁺ = cost(D,B⁺)/cost(D,B)"]]
    for _, r in runs.iterrows():
        rows.append([int(r.m), int(r.rep) + 1, f(r.ratio_hat, 5), g(r.cost_plus), f(r.ratio_plus, 5)])
    sm = [["m", "mean ratio B̂", "min–max B̂", "mean ratio B⁺", "min–max B⁺"]]
    for m in MS:
        x = agg[str(m)]
        sm.append([m, f(x["ratio_mean"]), f"{f(x['ratio_min'])}–{f(x['ratio_max'])}", f(x["ratio_plus_mean"]),
                   f"{f(x['ratio_plus_min'])}–{f(x['ratio_plus_max'])}"])
    st.append(T(sm)); st.append(Spacer(1, 4)); st.append(IMG("q1c_hat_vs_plus.png", 13 * cm))
    for t in t1["c"]:
        st.append(P(t, CM))
    st.append(P("All 25 runs (ratio of B̂ next to ratio of B⁺):", SMALL)); st.append(T(rows, fs=7))
    st.append(P("(d) Running time  [4 marks]", H2))
    rows = [["m", "compute E (s)", "k-means on E (s)", "E + k-means (s) mean ± sd", "speed-up vs (a)", "t draw A (s)", "t B̂ (s)",
             "total incl. A and B̂ (s)"]]
    for m in MS:
        x = agg[str(m)]
        rows.append([m, f(x["t_E_mean"], 4), f(x["t_kmeans_mean"], 3), f"{f(x['time_mean'], 3)} ± {f(x['time_std'], 3)}",
                     f(a["time_sec"] / x["time_mean"], 2), f(x["t_drawA_mean"], 4), f(x["t_Bhat_mean"], 4), f(x["time_total_mean"], 3)])
    st.append(T(rows, fs=7)); st.append(Spacer(1, 4)); st.append(IMG("q1d_time_vs_m.png", 12.5 * cm))
    for t in t1["d"]:
        st.append(P(t, CM))
    st.append(P("(e) Distortion of pairwise distances vs distortion of the k-means cost  [9 marks]", H2))
    e = R1["e"]
    rows = [["m", "(i) mean", "(i) std", "(i) IQR", "(i) min–max", "√(2/m)", "(ii) mean", "(ii) std", "(ii) IQR", "(ii) min–max"]]
    for m in MS:
        x = e[str(m)]
        rows.append([m, f(x["pair_mean"]), f(x["pair_std"]), f(x["pair_iqr"]), f"{f(x['pair_min'], 3)}–{f(x['pair_max'], 3)}",
                     f(x["pair_theory_std_sqrt_2_over_m"]), f(x["cost_mean"], 5), f(x["cost_std"], 5), f(x["cost_iqr"], 5),
                     f"{f(x['cost_min'], 4)}–{f(x['cost_max'], 4)}"])
    st.append(P(f"(i) {e['n_pairs']} random pairs (i≠l, D_i≠D_l; same pairs for every m), one draw of A per m. "
                f"(ii) {e['n_draws']} independent draws of A, clusters C_D from (a).", SMALL))
    st.append(T(rows, fs=7)); st.append(Spacer(1, 4)); st.append(IMG("q1e_boxplots.png", 15.5 * cm))
    st.append(IMG("q1e_boxplots_zoom_cost.png", 12.5 * cm))
    for t in t1["e"]:
        st.append(P(t, CM))
    # ---------------- Q2
    st.append(PageBreak())
    st.append(P("Question 2 — JL (CountSketch) for linear regression", H1))
    a2 = R2["a"]; agg2 = R2["bc"]
    MS2 = sorted(int(k) for k in agg2)
    st.append(P("(a) Exact least squares  [3 marks]", H2))
    st.append(T([["Loss(D,y,b)", "time to compute b (s)", "rank(D)", "d", "attack fraction of y"],
                 [g(a2["loss_b"]), f(a2["time_sec"], 4), a2["rank_D"], R2["d"] if False else S["d"], f(R2["attack_fraction"], 4)]]))
    st.append(Spacer(1, 3))
    for t in t2["a"]:
        st.append(P(t, CM))
    st.append(P("(b) CountSketch solutions  [12 marks]", H2))
    st.append(P("S has exactly one non-zero ±1 entry per column (bucket h(i) uniform in {1..m}, sign σ(i) uniform in {±1}); SD and Sy are formed in a "
                "single pass with numpy.add.at and S is never stored. Fresh S for each of the 5 repetitions.", SMALL))
    rows = [["m", "mean Loss(D,y,ã)", "mean ratio", "min ratio", "max ratio", "mean sketched loss", "sketched/Loss(b)", "ref. 1+r/(m−r−1) (Gaussian)"]]
    for m in MS2:
        x = agg2[str(m)]
        rows.append([m, g(x["loss_mean"]), f(x["ratio_mean"], 4), f(x["ratio_min"], 4), f(x["ratio_max"], 4), g(x["sketched_mean"]),
                     f(x["sketched_over_loss_b_mean"], 4), f(x["gaussian_reference_ratio"], 4) if x["gaussian_reference_ratio"] else "n/a (m ≤ r+1)"])
    st.append(T(rows, fs=7)); st.append(Spacer(1, 4)); st.append(IMG("q2b_ratio_vs_m.png", 12.5 * cm))
    st.append(IMG("q2b_sketched_loss_vs_m.png", 12.5 * cm))
    st.append(P(t2["b1"], CM))
    for t in t2["b2"]:
        if t:
            st.append(P(t, CM))
    runs2 = pd.read_csv(os.path.join(OUT, "q2_runs.csv"))
    rows = [["m", "run", "Loss(D,y,ã)", "ratio", "sketched loss ‖SDã−Sy‖²"]]
    for _, r in runs2.iterrows():
        rows.append([int(r.m), int(r.rep) + 1, g(r.loss), f(r.ratio, 5), g(r.sketched_loss)])
    st.append(P("All 35 runs:", SMALL)); st.append(T(rows, fs=7))
    st.append(P("(c) Running time  [4 marks]", H2))
    rows = [["m", "draw S (s)", "form SD, Sy (s)", "solve ã (s)", "total mean ± sd (s)", "exact solve (a) (s)", "speed-up"]]
    for m in MS2:
        x = agg2[str(m)]
        rows.append([m, f(x["t_draw"], 4), f(x["t_form"], 4), f(x["t_solve"], 4), f"{f(x['t_total'], 4)} ± {f(x['t_total_std'], 4)}",
                     f(a2["time_sec"], 4), f(a2["time_sec"] / x["t_total"], 2)])
    st.append(T(rows, fs=7)); st.append(Spacer(1, 4)); st.append(IMG("q2c_time_vs_m.png", 12.5 * cm))
    for t in t2["c"]:
        st.append(P(t, CM))
    st.append(P("(d) Distribution of ‖Sv‖²/‖v‖² for the residual v = Db − y  [5 marks]", H2))
    d2 = R2["d"]
    rows = [["m", "mean", "std", "min", "max", "exact theory std √(2/m·(1−‖v‖₄⁴/‖v‖₂⁴))", "√(2/m)"]]
    for m in [50, 500, 5000]:
        x = d2[str(m)]
        rows.append([m, f(x["mean"], 5), f(x["std"], 5), f(x["min"], 4), f(x["max"], 4), f(x["theory_std"], 5), f(x["approx_sqrt_2_over_m"], 5)])
    st.append(T(rows, fs=7)); st.append(Spacer(1, 4))
    st.append(IMG("q2d_hist_panels.png", 16 * cm)); st.append(IMG("q2d_hist_common_axis.png", 12 * cm))
    for t in t2["d"]:
        st.append(P(t, CM))
    st.append(P("(e) CountSketch versus dense Gaussian sketch on a 50,000-row subset  [6 marks]", H2))
    e2 = R2["e"]
    rows = [["sketch", "time to draw S & form SD′, Sy′ (s) mean ± sd", "solve time (s)", "ratio Loss(D′,y′,ã)/Loss(D′,y′,b′) mean ± sd", "min–max ratio"]]
    for k in ["CountSketch", "Dense Gaussian"]:
        x = e2[k]
        rows.append([k, f"{f(x['t_sketch_mean'], 4)} ± {f(x['t_sketch_std'], 4)}", f(x["t_solve_mean"], 4),
                     f"{f(x['ratio_mean'], 4)} ± {f(x['ratio_std'], 4)}", f"{f(x['ratio_min'], 4)}–{f(x['ratio_max'], 4)}"])
    st.append(T(rows, fs=7))
    st.append(P(f"One fixed subset (seed SEED), the same for both methods and all 5 repetitions; fresh sketch each repetition; m = {e2['m']}. "
                f"Exact solve on the subset: {f(e2['time_b_prime'], 4)} s.", SMALL))
    runs3 = pd.read_csv(os.path.join(OUT, "q2e_runs.csv"))
    rows = [["sketch", "rep", "sketch time (s)", "solve time (s)", "ratio"]]
    for _, r in runs3.iterrows():
        rows.append([r.method, int(r.rep) + 1, f(r.t_sketch, 4), f(r.t_solve, 4), f(r.ratio, 5)])
    st.append(T(rows, fs=7)); st.append(Spacer(1, 4))
    for t in t2["e"]:
        st.append(P(t, CM))
    st.append(P("Files submitted", H2))
    st.append(P("common.py, q1_kmeans.py, q2_regression.py, make_report.py, run_all.sh, requirements.txt, README.md; results/ (csv, json, npz, figs/) "
                "with every number and plot in this PDF."))
    doc.build(st)
    print("wrote", out)


if __name__ == "__main__":
    main()
