#!/usr/bin/env bash
# Usage: bash run_all.sh 24001 24002 ["Name One" "Name Two"]
# Runs Q1, Q2, builds the PDF and the submission zip.  Needs internet access once (fetch_kddcup99 downloads the data).
set -euo pipefail
R1=${1:?roll number 1}; R2=${2:?roll number 2}
export DSA_OUT=${DSA_OUT:-results}
python q1_kmeans.py   2>&1 | tee "$DSA_OUT.q1.log"  || true
python q2_regression.py 2>&1 | tee "$DSA_OUT.q2.log" || true
python make_report.py --rolls "$R1" "$R2" --discussed "${DISCUSSED:-None}" --urls "${URLS:-None}"
python make_zip.py "$R1" "$R2"
