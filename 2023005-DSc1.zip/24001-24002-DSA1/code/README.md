# CSE558 Data Science – Assignment 1 (JL / random projection on KDD Cup 99)

## How to run (about 10–40 min depending on the machine; needs internet once for the data download)

```bash
pip install -r requirements.txt
bash run_all.sh 24001 24002          # your two roll numbers
# optional: DISCUSSED="group of 24005-24006" URLS="https://..." bash run_all.sh 24001 24002
```
Or step by step:
```bash
python q1_kmeans.py          # Q1 (a)-(e)  -> results/q1_*.csv/json, results/figs/q1*.png
python q2_regression.py      # Q2 (a)-(e)  -> results/q2_*.csv/json, results/figs/q2*.png
python make_report.py --rolls 24001 24002 --names "Name One" "Name Two" \
       --discussed "names of groups you discussed with" --urls "URLs you used"
python make_zip.py 24001 24002    # -> 24001-24002-DSA1.zip  (submit this on Google Classroom)
```

## What each file does
| file | content |
|---|---|
| `common.py` | `fetch_kddcup99(subset=None, as_frame=True)`, construction of D (one-hot → drop constants → min–max, float32), y, exact k-means cost functions, projection helper, seeds |
| `q1_kmeans.py` | Q1 (a)–(e): k-means on D, B̂ / B⁺ from k-means on E=DAᵀ (m∈{5,10,15,20,25}, 5 runs each), timings, pairwise-distance vs cost distortion box plots |
| `q2_regression.py` | Q2 (a)–(e): exact lstsq, CountSketch (np.add.at, S never stored) for m∈{50…5000}, timings, residual-sketch histograms, CountSketch vs dense Gaussian on a 50 000-row subset |
| `make_report.py` | builds the PDF (all tables, plots, comments) from `results/` |
| `make_zip.py`, `run_all.sh` | packaging |

## Rules of the assignment that are enforced in the code
* No `sklearn.random_projection`; every random matrix is made with numpy (`np.random.default_rng`).
* `KMeans(n_clusters=15, n_init=5)` for every clustering of Q1; `numpy.linalg.lstsq` for every least-squares problem of Q2; `numpy.linalg.pinv` for A⁺.
* A ~ N(0, 1/m) (std 1/√m); E = DAᵀ; B̂ = means of the *original* rows of D inside the clusters found on E; cost(D,B̂) / cost(D,B⁺) by nearest-centre assignment.
* Q1(e): 10⁴ pairs with i≠l and D_i≠D_l, same pairs for all m; (i) one draw of A, (ii) 20 draws with clusters C_D from (a).
* Q2: CountSketch with bucket h(i) uniform, sign σ(i) uniform ±1, S never stored; (d) 100 sketches for m∈{50,500,5000}; (e) one fixed 50 000-row subset used for both sketches and all 5 repetitions, fresh sketch each repetition.
* Seeds: master `SEED=2026` in `common.py`; each random object uses `default_rng([SEED, task, m, rep])`; KMeans uses fixed `random_state`s. Re-running reproduces every number except wall-clock times.

## Things to do before you submit
1. Run it, open the PDF, **read the generated comments** (they are written from your actual numbers, but you are submitting them – edit the `q1_text` / `q2_text` functions in `make_report.py` if you want to change or extend any sentence, then re-run `make_report.py`).
2. Fill in `--discussed` and `--urls` (required by the assignment even if the answer is “none”).
3. Check that the zip contains the PDF, `code/` and `results/`; file name must be `rollno1-rollno2-DSA1.zip`; only one group member submits; submit by 23:59 on 22/11/26.
4. If memory is tight: D is float32 (≈ 0.25 GB); Q2 converts it to float64 (≈ 0.5 GB) for `lstsq`.
5. `np.add.at` is slow on old numpy (< 1.25); if Q2 takes very long, upgrade numpy – do not change the algorithm.

## Notes
* Q2 rank: with all dummy columns of the three categorical features kept, the dummies of each feature sum to 1 in every row, so rank(D) ≤ d − 2 (no intercept column is used). The code computes rank(D) numerically (`np.linalg.matrix_rank`) and uses that value for the “below / above m = rank(D)” discussion.
* Wall-clock times depend on the number of CPU threads; the report prints the machine information.
