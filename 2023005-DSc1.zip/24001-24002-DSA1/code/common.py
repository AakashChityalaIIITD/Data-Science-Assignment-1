"""Shared helpers for CSE558 Data Science Assignment 1 (JL / random projection on KDD Cup 99).

Everything that both questions need lives here: loading + building the data matrix D,
exact k-means cost functions, projection helper, timing and JSON helpers.
All randomness in the project is derived from SEED (see the q1/q2 scripts).
"""
import json
import os
import platform
import sys
import time

import numpy as np
import pandas as pd

SEED = 2026                                   # master seed: every random number derives from it
OUT = os.environ.get("DSA_OUT", "results")    # output directory (tables / json / figures)
FIG = os.path.join(OUT, "figs")
CAT_COLS = ["protocol_type", "service", "flag"]


# ----------------------------------------------------------------------------- misc
def ensure_dirs():
    os.makedirs(FIG, exist_ok=True)


def tic():
    return time.perf_counter()


class NpEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, np.integer):
            return int(o)
        if isinstance(o, np.floating):
            return float(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
        return super().default(o)


def save_json(obj, name):
    ensure_dirs()
    with open(os.path.join(OUT, name), "w") as f:
        json.dump(obj, f, indent=2, cls=NpEncoder)


def load_json(name):
    with open(os.path.join(OUT, name)) as f:
        return json.load(f)


def env_info():
    import sklearn
    try:
        from threadpoolctl import threadpool_info
        blas = [f"{p.get('internal_api')}:{p.get('num_threads')}" for p in threadpool_info()]
    except Exception:  # pragma: no cover
        blas = []
    return {
        "python": sys.version.split()[0],
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "sklearn": sklearn.__version__,
        "platform": platform.platform(),
        "cpu_count": os.cpu_count(),
        "threadpools": blas,
        "SEED": SEED,
    }


# ----------------------------------------------------------------------------- data
def _s(v):
    return v.decode() if isinstance(v, bytes) else str(v)


def _num(col):
    if col.dtype == object:
        col = col.map(_s)
    return pd.to_numeric(col)


def load_kdd():
    """Exactly the call prescribed in the assignment (default 10% version)."""
    from sklearn.datasets import fetch_kddcup99
    return fetch_kddcup99(subset=None, as_frame=True)


def build_D(kdd):
    """(i) one-hot encode 3 text features, other 38 -> float; (ii) drop constant columns;
    (iii) min-max rescale every column to [0,1].  Returns (D float32, summary dict)."""
    X = kdd.data
    num_cols = [c for c in X.columns if c not in CAT_COLS]
    cat = pd.get_dummies(X[CAT_COLS].apply(lambda s: s.map(_s)), dtype=np.float64)   # (i)
    num = X[num_cols].apply(_num).astype(np.float64)                                  # (i)
    M = pd.concat([num, cat], axis=1)
    assert not M.isna().any().any(), "NaNs found"
    n_before = M.shape[1]
    lo, hi = M.min(), M.max()
    const = lo == hi                                                                  # (ii)
    dropped = [str(c) for c in M.columns[const]]
    M = M.loc[:, ~const]
    lo, hi = lo[~const], hi[~const]
    D = ((M - lo) / (hi - lo)).to_numpy(dtype=np.float32)                             # (iii)
    groups = {}
    for c in CAT_COLS:
        pref = c + "_"
        total = int((cat.columns.str.startswith(pref)).sum())
        kept = int(sum(1 for col in M.columns if str(col).startswith(pref)))
        groups[c] = {"dummies_total": total, "dummies_kept": kept}
    labels = kdd.target.map(_s)
    summary = {
        "n": int(D.shape[0]), "d": int(D.shape[1]),
        "columns_before_dropping": int(n_before),
        "n_numeric_columns": len(num_cols),
        "n_onehot_columns": int(cat.shape[1]),
        "dropped_constant_columns": dropped,
        "onehot_groups": groups,
        "min_value": float(D.min()), "max_value": float(D.max()),
        "n_distinct_labels": int(labels.nunique()),
        "label_counts": {k: int(v) for k, v in labels.value_counts().items()},
        "attack_fraction": float((labels != "normal.").mean()),
        "n_distinct_rows": int(len(pd.DataFrame(D).drop_duplicates())),
        "dtype": str(D.dtype),
    }
    return D, summary


def build_y(kdd):
    y = (kdd.target != b"normal.").to_numpy(dtype=float)       # line given in the assignment
    if y.min() == y.max():                                      # labels were str, not bytes
        y = (kdd.target.map(_s) != "normal.").to_numpy(dtype=float)
    assert 0 < y.mean() < 1
    return y


# ----------------------------------------------------------------------------- k-means costs
def assign(D, B, chunk=50000):
    """Nearest centre of every row of D; returns (cost(D,B), index array).
    The nearest centre is found with the expansion |x|^2-2x.b+|b|^2, but the reported
    squared distance is recomputed exactly as |x-b_j|^2 (float64) to avoid cancellation."""
    B64 = np.asarray(B, dtype=np.float64)
    bn = (B64 ** 2).sum(1)
    idx = np.empty(len(D), dtype=np.int64)
    tot = 0.0
    for s in range(0, len(D), chunk):
        X = np.asarray(D[s:s + chunk], dtype=np.float64)
        d2 = (X ** 2).sum(1)[:, None] - 2.0 * (X @ B64.T) + bn[None, :]
        j = d2.argmin(1)
        idx[s:s + chunk] = j
        diff = X - B64[j]
        tot += float(np.einsum("ij,ij->", diff, diff))
    return tot, idx


def cost_centres(D, B):
    """cost(D,B) = sum_i min_{b in B} |D_i-b|^2."""
    return assign(D, B)[0]


def cluster_means(X, labels, k, chunk=100000):
    """Mean of the rows of X in each of the k clusters (float64), plus the cluster sizes."""
    sums = np.zeros((k, X.shape[1]))
    for s in range(0, len(X), chunk):
        ind = np.eye(k)[labels[s:s + chunk]]
        sums += ind.T @ np.asarray(X[s:s + chunk], dtype=np.float64)
    cnt = np.bincount(labels, minlength=k).astype(float)
    mu = sums / np.maximum(cnt, 1.0)[:, None]
    return mu, cnt


def cost_partition(X, labels, k, chunk=100000):
    """cost_X(C) = sum_j sum_{i in C_j} |X_i - mu_j(X)|^2 for the partition given by labels."""
    mu, _ = cluster_means(X, labels, k, chunk)
    tot = 0.0
    for s in range(0, len(X), chunk):
        diff = np.asarray(X[s:s + chunk], dtype=np.float64) - mu[labels[s:s + chunk]]
        tot += float(np.einsum("ij,ij->", diff, diff))
    return tot


def project(D, A, dtype=np.float64, chunk=100000):
    """E = D A^T computed in chunks (row i of E is A D_i)."""
    E = np.empty((len(D), A.shape[0]), dtype=dtype)
    AT = np.asarray(A, dtype=dtype).T
    for s in range(0, len(D), chunk):
        E[s:s + chunk] = np.asarray(D[s:s + chunk], dtype=dtype) @ AT
    return E
