"""python make_zip.py ROLL1 ROLL2  ->  ROLL1-ROLL2-DSA1.zip containing the answers PDF, all code, and results/."""
import glob, os, sys, zipfile

r1, r2 = sys.argv[1], sys.argv[2]
out_dir = os.environ.get("DSA_OUT", "results")
name = f"{r1}-{r2}-DSA1"
pdf = os.path.join(out_dir, f"{r1}-{r2}-DSA1_answers.pdf")
assert os.path.exists(pdf), f"{pdf} not found - run make_report.py --rolls {r1} {r2} first"
code = ["common.py", "q1_kmeans.py", "q2_regression.py", "make_report.py", "make_zip.py", "run_all.sh",
        "requirements.txt", "README.md"]
with zipfile.ZipFile(name + ".zip", "w", zipfile.ZIP_DEFLATED) as z:
    z.write(pdf, f"{name}/{r1}-{r2}-DSA1_answers.pdf")          # PDF of answers at the top level
    for c in code:
        z.write(c, f"{name}/code/{c}")
    for p in glob.glob(os.path.join(out_dir, "**", "*"), recursive=True):
        if os.path.isfile(p) and not p.endswith(".pdf"):
            z.write(p, f"{name}/results/{os.path.relpath(p, out_dir)}")
    for log in glob.glob(out_dir + ".q*.log"):
        z.write(log, f"{name}/results/{os.path.basename(log)}")
print("created", name + ".zip")
